To update the GitHub Pages at http://gflags.github.io/gflags/, use command:
```
git subtree push --prefix=doc/ origin gh-pages
```
